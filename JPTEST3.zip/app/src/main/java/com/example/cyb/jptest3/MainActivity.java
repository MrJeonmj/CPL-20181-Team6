package com.example.cyb.jptest3;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends Activity {
    TextView checkBoxStatus, editTextStatus,idTextStatus;

    ArrayList<HashMap<String, String>> mArrayList;

    private static String TAG = "phptest_MainActivity";

    private static String TAG_JSON="webnautes";
    private static String TAG_ID = "ID";
    private static String TAG_PW = "PW";
    private static String TAG_NAME ="NAME";
    private static String TAG_CALLNUM = "CALL_NUM";
    private static String TAG_ADDRESS = "ADDRESS";
    private static String TAG_DATEB = "DATE_OF_BIRTH";

    static String id;
    phpdo task;
    String mJsonString;



    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        id = "chaye123";

        // 요소들 정의
        Button buttonSetPreference = (Button) findViewById(R.id.userbutton);
        checkBoxStatus = (TextView) findViewById(R.id.checkboxstatus);
        editTextStatus = (TextView) findViewById(R.id.edittextstatus);
        idTextStatus = (TextView) findViewById(R.id.idstatus);

        SharedPreferences prefer = PreferenceManager.getDefaultSharedPreferences(this);

        mArrayList = new ArrayList<>();
        task = new phpdo();
        task.execute(id);



        //버튼 누르면 인텐트 전환
        buttonSetPreference
                .setOnClickListener(new Button.OnClickListener() {
                    public void onClick(View arg0) {



                        Intent intent = new Intent(MainActivity.this, setting.class);
                        startActivity(intent);

                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "onResume", Toast.LENGTH_LONG).show();

        SharedPreferences prefer = PreferenceManager
                .getDefaultSharedPreferences(this);

        task = new phpdo();
        task.execute(id);

        SharedPreferences.Editor editor = prefer.edit();
        editor.putString("idvalue",id ); //키값, 저장값
        editor.putString("pwvalue",TAG_PW );
        editor.putString("namevalue",TAG_NAME);
        editor.putString("vphonevalue",TAG_CALLNUM );
        editor.putString("homevalue",TAG_ADDRESS );
        editor.putString("birthvalue",TAG_DATEB );
        editor.commit();

        checkBoxStatus.setText("CheckBox 상태값 : "
                + prefer.getBoolean("checkboxvalue", true));
        editTextStatus.setText("EditText 상태값 : "
                + prefer.getString("edittexvalue", ""));
        idTextStatus.setText("ID : "
                + prefer.getString("idvalue", "자기 아이디 값"));
    }



    private class phpdo extends AsyncTask<String, Void ,String> {

        protected void onPreExecute(){

        }
        @Override
        protected String doInBackground(String... arg0) {

            try {

                String link = "http://show8258.ipdisk.co.kr:8000/setting_userlist.php?ID="+ id;
                URL url = new URL(link);
                HttpClient client = new DefaultHttpClient();
                HttpGet request = new HttpGet();
                request.setURI(new URI(link));
                HttpResponse response = client.execute(request);
                BufferedReader in = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

                StringBuffer sb = new StringBuffer("");
                String line = "";

                while ((line = in.readLine()) != null) {
                    sb.append(line);
                    break;
                }
                in.close();
                return sb.toString();
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }

        }

        @Override
        protected void onPostExecute(String result){


            if(result != null){
                mJsonString = result;
                showResult();
            }

        }
    }

    private void showResult(){
        try {
            JSONObject jsonObject = new JSONObject(mJsonString);

                TAG_ID = jsonObject.getString("ID");
                TAG_PW = jsonObject.getString("PW");
                TAG_NAME = jsonObject.getString("NAME");
                TAG_CALLNUM = jsonObject.getString("CALL_NUM");
                TAG_ADDRESS = jsonObject.getString("ADDRESS");
                TAG_DATEB = jsonObject.getString("DATE_OF_BIRTH");


        }catch (JSONException e) {
            e.printStackTrace();
        }

    }

}

